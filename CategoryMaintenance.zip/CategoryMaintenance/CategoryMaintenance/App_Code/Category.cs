﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Category
/// </summary>
public class Category
{
    public Category()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string CategoryID { get; set; }
    public string LongName { get; set; }
    public string  ShortName { get; set; }

}