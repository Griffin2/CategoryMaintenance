﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

/// <summary>
/// Summary description for CategoryDB
/// </summary>

[DataObject(true)]
public class CategoryDB
{
    public CategoryDB()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //Connects to DB from WEBCONFIG
    private static string GetConnectionString()
    {
        return ConfigurationManager.ConnectionStrings["HalloweenConnectionString"].ConnectionString;
    }

    //SELECTS CATEGORIES FROM DB
    [DataObjectMethod(DataObjectMethodType.Select)]
    public static List<Category> GetAllCategories()
    {
        List<Category> categoryList = new List<Category>();

        //STORED PROCEDURE WOULD BE BETTER PRACTICE
        string select = "SELECT CATEGORYID, LONGNAME, SHORTNAME FROM CATEGORIES ORDER BY LONGNAME";
        using (SqlConnection connection = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(select, connection))
            {
                connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Category category = new Category();
                    category.CategoryID = reader["CategoryID"].ToString();
                    category.ShortName = reader["ShortName"].ToString();
                    category.LongName = reader["LongName"].ToString();
                    categoryList.Add(category);
                }
                reader.Close();
            }
        }
        return categoryList;
    }

    //SELECTS PRODUCT DATA FROM SPECIFIC CATEGORY
    [DataObjectMethod(DataObjectMethodType.Select)]
    public static IEnumerable GetProductsFromCategory(string CategoryID)
    {
        SqlConnection connection = new SqlConnection(GetConnectionString());

        //STORED PROCEDURE WOULD BE BETTER PRACTICE
        string select = "SELECT PRODUCTID, NAME, UNITPRICE, ONHAND FROM PRODUCTS" +
            " WHERE CATEGORYID = @CATEGORYID";

        SqlCommand cmd = new SqlCommand(select, connection);
        cmd.Parameters.AddWithValue("CategoryID", CategoryID);

        connection.Open();
        SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        return reader;
    }

    //INSERTS A NEW CATEGORY
    [DataObjectMethod(DataObjectMethodType.Insert)]
    public static void InsertCategory(Category category)
    {
        List<Category> categoryList = new List<Category>();

        //STORED PROCEDURE WOULD BE BETTER PRACTICE
        string select = "INSERT INTO CATEGORIES " +
            "(CategoryID, ShortName, LongName)" + 
            "VALUES (@CategoryID, @ShortName, @LongName)";

        using (SqlConnection connection = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(select, connection))
            {
                cmd.Parameters.AddWithValue("CategoryID", category.CategoryID);
                cmd.Parameters.AddWithValue("ShortName", category.ShortName);
                cmd.Parameters.AddWithValue("LongName", category.LongName);
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    //DELETES CATEGORY FROM DB
    [DataObjectMethod(DataObjectMethodType.Delete)]
    public static int DeleteCategory(Category category)
    {
        int deleteCount = 0;
        //STORED PROCEDURE WOULD BE BETTER PRACTICE
        string select = "DELETE FROM CATEGORIES " +
            "WHERE CategoryID = @CategoryID " +
            "AND ShortName = @ShortName " +
            "AND LongName = @LongName ";

        using (SqlConnection connection = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(select, connection))
            {
                cmd.Parameters.AddWithValue("CategoryID", category.CategoryID);
                cmd.Parameters.AddWithValue("ShortName", category.ShortName);
                cmd.Parameters.AddWithValue("LongName", category.LongName);
                connection.Open();
                deleteCount = cmd.ExecuteNonQuery();
            }
        }
        return deleteCount;
    }

    //UPDATES CATEGORY FROM DB
    [DataObjectMethod(DataObjectMethodType.Update)]
    public static int UpdateCategory(Category original_Category, Category category)
    {
        int updateCount = 0;
        //STORED PROCEDURE WOULD BE BETTER PRACTICE
        string select = "UPDATE CATEGORIES " +
            "SET ShortName = @ShortName, LongName = @LongName " +
            "WHERE  CategoryID = @original_CategoryID " +
            "AND ShortName = @original_ShortName " +
            "AND LongName = @original_LongName ";

        using (SqlConnection connection = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(select, connection))
            {
                cmd.Parameters.AddWithValue("ShortName", category.ShortName);
                cmd.Parameters.AddWithValue("LongName", category.LongName);
                cmd.Parameters.AddWithValue("original_CategoryID", original_Category.CategoryID);
                cmd.Parameters.AddWithValue("original_ShortName", original_Category.ShortName);
                cmd.Parameters.AddWithValue("original_LongName", original_Category.LongName);
                connection.Open();
                updateCount = cmd.ExecuteNonQuery();
            }
        }
        return updateCount;
    }

   
}